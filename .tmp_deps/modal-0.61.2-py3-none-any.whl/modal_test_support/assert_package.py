# Copyright Modal Labs 2022
# See test in client_test/package_utils_test.py

name = "xyz"
