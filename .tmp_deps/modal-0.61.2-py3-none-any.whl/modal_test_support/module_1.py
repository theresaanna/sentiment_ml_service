# Copyright Modal Labs 2022
def square(x):
    return x**2
