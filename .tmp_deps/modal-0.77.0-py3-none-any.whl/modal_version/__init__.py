# Copyright Modal Labs 2025
"""Supplies the current version of the modal client library."""

__version__ = "0.77.0"
