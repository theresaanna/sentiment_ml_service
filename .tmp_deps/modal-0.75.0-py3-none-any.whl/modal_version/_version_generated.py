# Copyright Modal Labs 2025

# Note: Reset this value to -1 whenever you make a minor `0.X` release of the client.
build_number = 0  # git: 0f7fb1e
